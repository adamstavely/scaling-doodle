# Third-party notices

Trenchcoat includes code adapted from the projects below, under their licences.

## ztd-charts

https://github.com/Junhan2/ztd-charts – the chart engine in `src/elements/internal/chart/` (scales, layouts, data
parsing, text measuring, the spring motion engine, the brush, the chart spec and chart suggestions), the charts built
on it (`tc-bar-chart` and the rest of the Charts section, and `tc-chart`), and `@adamstavely/trenchcoat/charts`, ported from React
to Lit.

```
MIT License

Copyright (c) 2026 Junhan2

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```
